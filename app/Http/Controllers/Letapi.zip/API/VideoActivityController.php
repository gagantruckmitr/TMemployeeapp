<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\DriverVideoProgress;
use App\Models\Videowatch;
use App\Models\Video;
use Illuminate\Support\Facades\Auth;

class VideoActivityController extends Controller
{
    //  Save watch activity
public function saveWatchActivity(Request $request)
{
    try {
        $request->validate([
            'video_id' => 'required|exists:Videos,id',
            'watch_time' => 'required|string',
        ]);

        $user = Auth::user();

        // Save current watch activity
        $watch = Videowatch::create([
            'user_id' => $user->id,
            'video_id' => $request->video_id,
            'watch_time' => $request->watch_time,
        ]);

        $currentVideo = Video::find($request->video_id);

        // Update progress for current video
        DriverVideoProgress::updateOrCreate(
            ['driver_id' => $user->id, 'video_id' => $request->video_id],
            [
                'module_id' => $currentVideo->module,
                'quize_status' => 0,
                'is_completed' => true
            ]
        );

        // Get the next video in the same module
        $nextVideo = Video::where('module', $currentVideo->module)
                          ->where('id', '>', $currentVideo->id)
                          ->orderBy('id', 'asc')
                          ->first();

        if ($nextVideo) {
            // Ensure next video row is initialized (play_status will show true on list)
            DriverVideoProgress::firstOrCreate(
                ['driver_id' => $user->id, 'video_id' => $nextVideo->id],
                [
                    'module_id' => $nextVideo->module,
                    'quize_status' => 0,
                    'is_completed' => false
                ]
            );
        }

        return response()->json([
            'success' => true,
            'message' => 'Watch activity saved. Next video unlocked.',
            'data' => $watch,
            'play_status' => true
        ]);
    } catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => 'Validation error.',
            'errors' => $e->errors(),
            'play_status' => false
        ], 422);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Internal server error.',
            'error' => $e->getMessage(),
            'line' => $e->getLine(),
            'file' => $e->getFile(),
            'play_status' => false
        ], 500);
    }
}



public function listVideos(Request $request)
{
    try {
        $user = Auth::user();

        $videos = Video::with(['moduleData', 'topicData'])->get();

        // Group videos by module
        $grouped = $videos->groupBy('module')->sortKeys()->map(function ($videoGroup, $moduleId) {
            return $videoGroup->sortBy('id')->values(); // ensure videos are sorted
        });

        $result = [];
        $previousModuleCompleted = true;

        foreach ($grouped as $moduleId => $videoGroup) {
            $module = $videoGroup->first()->moduleData;

            if (!$module) {
                continue;
            }

            $moduleCompleted = true;
            $videosArray = [];

            foreach ($videoGroup as $index => $video) {
                $playStatus = false;

                if ($moduleId == 1 && $index == 0) {
                    // First video of module 1
                    $playStatus = true;
                } elseif ($previousModuleCompleted && $index == 0) {
                    // First video of current module if previous module is completed
                    $playStatus = true;
                } else {
                    // Check if user has already started/completed the video
                    $playStatus = DriverVideoProgress::where('driver_id', $user->id)
                        ->where('video_id', $video->id)
                        ->exists();
                }

                // If any video is not started, mark module as not completed
                if (!DriverVideoProgress::where('driver_id', $user->id)
                        ->where('video_id', $video->id)
                        ->exists()) {
                    $moduleCompleted = false;
                }

                $videosArray[] = [
                    'id' => $video->id,
                    'topic' => $video->topic,
                    'topic_name' => optional($video->topicData)->topic_name,
                    'video_title_name' => $video->video_title_name,
                    'video' => $video->video,
                    'thumbnail_url' => $video->video 
                        ? preg_replace('/\.\w+$/', '.png', $video->video)
                        : null,
                    'play_status' => $playStatus,
                ];
            }

            $result[] = [
                'module' => [
                    'id' => $module->id,
                    'name' => $module->name,
                ],
                'videos' => collect($videosArray)->values(),
            ];

            $previousModuleCompleted = $moduleCompleted;
        }

        return response()->json([
            'success' => true,
            'message' => 'Videos grouped by module fetched successfully.',
            'data' => $result
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Internal Server Error',
            'error' => $e->getMessage()
        ], 500);
    }
}




    //  Save Rating & Completion
    
public function rateAndCompleteVideo(Request $request)
    {
        try {
            $request->validate([
                'video_id' => 'required|exists:Videos,id',
                'module_id' => 'required',
                'quize_status' => 'required|integer',
                'is_completed' => 'required|boolean'
            ]);
            

            $user = Auth::user();

            $progress = DriverVideoProgress::updateOrCreate(
                ['driver_id' => $user->id, 'video_id' => $request->video_id],
                [
                    'module_id' => $request->module_id,
                    'quize_status' => $request->quize_status,
                    'is_completed' => $request->is_completed
                ]
            );

            return response()->json([
                'message' => 'Progress updated successfully.',
                'data' => $progress
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Internal server error.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
