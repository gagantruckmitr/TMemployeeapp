<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    // Capture Subscription
public function capture(Request $request)
{
    $request->validate([
        'unique_id' => 'required',
        'start_at' => 'required|numeric',  // Expecting a number for Unix timestamp
        'end_at' => 'required|numeric',    // Expecting a number for Unix timestamp
        'amount' => 'required|numeric',
        'payment_id' => 'required',
        'payment_status' => 'required',
        'payment_details' => 'nullable|string',
    ]);

    $user = Auth::user();

    $payment = Payment::create([
        'user_id' => $user->id,
        'unique_id' => $request->unique_id,
        'start_at' => $request->start_at,  // Directly storing the Unix timestamp
        'end_at' => $request->end_at,      // Directly storing the Unix timestamp
        'amount' => $request->amount,
        'payment_id' => $request->payment_id,
        'payment_status' => $request->payment_status,
        'payment_details' => $request->payment_details,
    ]);

    return response()->json([
        'status' => true,
        'message' => 'Payment captured successfully',
        'data' => $payment,
    ], 201);
}


    // Get Payment Details
    public function details()
    {
        $user = Auth::user();
        $payments = $user->payments()->latest()->get();

        return response()->json([
            'status' => true,
            'data' => $payments,
        ]);
    }
	
	 public function delete($id)
    {
        $user = Auth::user();

        $payment = Payment::where('id', $id)->where('user_id', $user->id)->first();

        if (!$payment) {
            return response()->json([
                'status' => false,
                'message' => 'Payment not found or unauthorized.',
            ], 404);
        }

        $payment->delete();

        return response()->json([
            'status' => true,
            'message' => 'Payment deleted successfully.',
        ]);
    }
}
